from gridworld import GridWorld

mask_data = """
0 -inf -1 -1 -1
-1 -inf -1 -inf -1
-1 -inf -1 -inf -1
-1 -1 -1 -inf -1
-3 -3 -3 -3 -3
"""
my_world = GridWorld(mask_data)